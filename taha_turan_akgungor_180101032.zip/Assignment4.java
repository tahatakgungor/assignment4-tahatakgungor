import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Assignment4 {
	static int[] frame;
	static int frameNumber;
	static ArrayList <Integer> a1 = new ArrayList<>();
	static int size=0;
	static int counter=0;
	
	public static void main(String[] args) {
		  read(args[2]);
		  frameNumber= Integer.parseInt(args[0]);
		  frame = new int[frameNumber];
		  
		  if(args[1].charAt(0) == 'F') {
			  fifo();
		  }else if(args[1].charAt(0) == 'L') {
			  lru();
		  }
		  System.out.println("\nTotal number of page faults is " + counter);
	}
	
	public static void lru() {
		Queue<Integer> q1 = new LinkedList<>();
		for(int i=0; i<frameNumber; i++) {
			frame[i] = a1.get(i);
			print(a1.get(i), false);
			q1.add(a1.get(i));
		}
		
		for(int i = frameNumber; i<size; i++ ) {
			int index = control(a1.get(i));
			if(index == -1) {
				if(q1.contains(a1.get(i))) {
					System.out.println("test");
				}else {
					int temp=q1.remove();
					int index1 = control(temp);
					frame[index1] = a1.get(i);
					q1.add(a1.get(i));
					print(a1.get(i), true);
				}
			}else {
				Queue<Integer> q2 = new LinkedList<>();
				while(!q1.isEmpty()) {
					if(q1.peek() != a1.get(i)) {
						q2.add(q1.peek());
						q1.remove();
					} else {
						q1.remove();
					}
				}
				q1=q2;
				q1.add(a1.get(i));
				print(a1.get(i), false);
			}
		}
		
	}
	
	public static void fifo() {
		for(int i=0; i<frameNumber; i++) {
			frame[i] = a1.get(i);
			print(a1.get(i), false);
		}
		
		int reminder = 0;
		
		for(int i = frameNumber; i<size; i++ ) {
			int index = control(a1.get(i));
			
			if(index == -1) {
				frame[reminder] = a1.get(i);
				print(a1.get(i), true);
				reminder++;
				if(reminder > frameNumber-1) {
					reminder=0;
				}
			} else {
				print(a1.get(i), false);
			}
		}
	}
	
	public static int control(Integer x) {
		for(int i=0; i<frameNumber; i++) {
			if(frame[i] == x) {
				return i;
			}
		}
		return -1;
	}
	
	public static void print(Integer x, boolean fault) {
		System.out.print(x + " --> [ ");
		
		for(int i=0; i<frameNumber; i++) {
			System.out.print(frame[i]+" ");
		}
		
		System.out.print("] ");
		if(fault) {
			System.out.print("page fault");
			counter++;
		}
		System.out.println();
	}
	
	public static void read(String text) {
		  Scanner scan = null;
	      File f = new File(text);
	      
	      try {
	         scan = new Scanner(f);
	      } catch (FileNotFoundException e) {
	         System.out.println("File not found.");
	         System.exit(0);
	      }
	      
	      while (scan.hasNextLine()) { 
	         String currentLine = scan.nextLine();
	         String words[] = currentLine.split(" ");

	         for(String str : words) {
	            try {
	               a1.add(Integer.parseInt(str));
	               size++;
	            }catch(NumberFormatException nfe) { }; 
	         }
	      }
	      scan.close();
	}
}